import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.tree import DecisionTreeRegressor

# Load dataset
file_path = '/content/UCI_Credit_Card_20k.csv'
data = pd.read_csv(file_path)

# Define features and target
X = data.drop(columns=['ID', 'default.payment.next.month']).values
y = data['default.payment.next.month'].values

# Normalize numerical features
class StandardScalerCustom:
    def fit_transform(self, X):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0)
        return (X - self.mean) / self.std

scaler = StandardScalerCustom()
X = scaler.fit_transform(X)

# Train-test split
class TrainTestSplitCustom:
    def split(self, X, y, test_size=0.2, random_state=None):
        if random_state is not None:
            np.random.seed(random_state)
        indices = np.arange(X.shape[0])
        np.random.shuffle(indices)
        test_size = int(test_size * len(indices))
        train_indices = indices[:-test_size]
        test_indices = indices[-test_size:]
        return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

splitter = TrainTestSplitCustom()
X_train, X_test, y_train, y_test = splitter.split(X, y, test_size=0.2, random_state=42)

# Gradient Boosting Custom
class GradientBoostingCustom:
    def __init__(self, n_estimators=100, learning_rate=0.1):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.models = []
        self.initial_prediction = None
        self.train_residuals = []

    def fit(self, X, y):
        self.initial_prediction = np.mean(y)
        residuals = y - self.initial_prediction

        for _ in range(self.n_estimators):
            tree = DecisionTreeRegressor(max_depth=3)
            tree.fit(X, residuals)
            prediction = tree.predict(X)
            residuals -= self.learning_rate * prediction
            self.models.append(tree)
            self.train_residuals.append(np.mean(np.abs(residuals)))

    def predict(self, X):
        pred = np.full(X.shape[0], self.initial_prediction)
        for model in self.models:
            pred += self.learning_rate * model.predict(X)
        return np.round(pred)

    def feature_importances(self):
        importances = np.zeros(X_train.shape[1])
        for model in self.models:
            importances += model.feature_importances_
        return importances / self.n_estimators

# Train model
gb = GradientBoostingCustom(n_estimators=100, learning_rate=0.1)
gb.fit(X_train, y_train)
y_pred = gb.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")

# Save results
results_df = pd.DataFrame({
    'Actual': y_test,
    'Predicted': y_pred
})
results_df.to_csv('/content/gradient_boosting_results_custom.csv', index=False)

# Confusion matrix plot
conf_mat = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6,4))
sns.heatmap(conf_mat, annot=True, fmt='d', cmap='Blues', xticklabels=[0,1], yticklabels=[0,1])
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()

# Residuals plot
plt.figure(figsize=(8,4))
plt.plot(gb.train_residuals, label='Mean Absolute Residual per Iteration')
plt.title('Residuals vs Boosting Iterations')
plt.xlabel('Boosting Iteration')
plt.ylabel('Mean Absolute Residual')
plt.grid(True)
plt.legend()
plt.show()

# Feature importance
feature_names = data.drop(columns=['ID', 'default.payment.next.month']).columns
importances = gb.feature_importances()
sorted_idx = np.argsort(importances)[::-1]

plt.figure(figsize=(10,6))
sns.barplot(x=importances[sorted_idx], y=feature_names[sorted_idx])
plt.title('Feature Importances')
plt.xlabel('Average Importance')
plt.ylabel('Features')
plt.show()
accuracy, results_csv_path
