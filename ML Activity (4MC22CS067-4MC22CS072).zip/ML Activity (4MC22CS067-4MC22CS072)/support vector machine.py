import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler

# Load dataset
file_path = '/content/UCI_Credit_Card_20k.csv'
data = pd.read_csv(file_path)

# Define features and target
X = data.drop(columns=['ID', 'default.payment.next.month']).values
y = data['default.payment.next.month'].values

# Normalize features using sklearn StandardScaler
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Train-test split (custom)
class TrainTestSplitCustom:
    def split(self, X, y, test_size=0.2, random_state=None):
        if random_state is not None:
            np.random.seed(random_state)
        indices = np.arange(X.shape[0])
        np.random.shuffle(indices)
        test_size = int(test_size * len(indices))
        train_indices = indices[:-test_size]
        test_indices = indices[-test_size:]
        return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

splitter = TrainTestSplitCustom()
X_train, X_test, y_train, y_test = splitter.split(X, y, test_size=0.2, random_state=42)

# SVM Classifier
svm_model = SVC(kernel='linear', C=1.0)  # You can change to 'rbf', 'poly' etc.
svm_model.fit(X_train, y_train)

# Prediction
y_pred = svm_model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")

# Save results
results_df = pd.DataFrame({
    'Actual': y_test,
    'Predicted': y_pred
})
results_csv_path = '/content/svm_results_custom.csv'
results_df.to_csv(results_csv_path, index=False)

# Confusion Matrix
conf_mat = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6,4))
sns.heatmap(conf_mat, annot=True, fmt='d', cmap='Purples', xticklabels=[0,1], yticklabels=[0,1])
plt.title('SVM Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Feature importance approximation for linear kernel
if svm_model.kernel == 'linear':
    feature_names = data.drop(columns=['ID', 'default.payment.next.month']).columns
    importance = np.abs(svm_model.coef_[0])
    sorted_idx = np.argsort(importance)[::-1]

    plt.figure(figsize=(10,6))
    sns.barplot(x=importance[sorted_idx], y=feature_names[sorted_idx])
    plt.title('Approximate Feature Importances (Linear SVM)')
    plt.xlabel('Weight Magnitude')
    plt.ylabel('Features')
    plt.tight_layout()
    plt.show()
