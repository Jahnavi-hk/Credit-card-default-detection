import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay, classification_report, roc_curve, auc
from sklearn.tree import DecisionTreeClassifier  # Used inside RandomForestCustom

# Load dataset
file_path = '/content/UCI_Credit_Card_20k.csv'
data = pd.read_csv(file_path)
X = data.drop(columns=['ID', 'default.payment.next.month']).values
y = data['default.payment.next.month'].values

# Normalize
class StandardScalerCustom:
    def fit_transform(self, X):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0)
        return (X - self.mean) / self.std

scaler = StandardScalerCustom()
X = scaler.fit_transform(X)

# Train-Test Split
class TrainTestSplitCustom:
    def split(self, X, y, test_size=0.2, random_state=None):
        if random_state is not None:
            np.random.seed(random_state)
        indices = np.arange(X.shape[0])
        np.random.shuffle(indices)
        test_size = int(test_size * len(indices))
        train_idx, test_idx = indices[:-test_size], indices[-test_size:]
        return X[train_idx], X[test_idx], y[train_idx], y[test_idx]

splitter = TrainTestSplitCustom()
X_train, X_test, y_train, y_test = splitter.split(X, y, test_size=0.2, random_state=42)

# Decision Tree wrapper
class DecisionTreeCustom:
    def __init__(self, max_depth=None):
        self.model = DecisionTreeClassifier(max_depth=max_depth)
    
    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

    def feature_importances(self):
        return self.model.feature_importances_

# Random Forest Custom
class RandomForestCustom:
    def __init__(self, n_estimators=10, max_depth=None):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.trees = []

    def _bootstrap(self, X, y):
        indices = np.random.choice(X.shape[0], X.shape[0], replace=True)
        return X[indices], y[indices]

    def fit(self, X, y):
        self.trees = []
        for _ in range(self.n_estimators):
            X_samp, y_samp = self._bootstrap(X, y)
            tree = DecisionTreeCustom(max_depth=self.max_depth)
            tree.fit(X_samp, y_samp)
            self.trees.append(tree)

    def predict(self, X):
        predictions = np.array([tree.predict(X) for tree in self.trees])
        return np.apply_along_axis(lambda x: np.bincount(x).argmax(), axis=0, arr=predictions)

    def feature_importances(self):
        all_importances = np.array([tree.feature_importances() for tree in self.trees])
        return np.mean(all_importances, axis=0)

# Train and evaluate
rf = RandomForestCustom(n_estimators=10, max_depth=5)
rf.fit(X_train, y_train)
y_pred = rf.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)

# Save results
results_df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
results_csv_path = '/content/random_forest_results_custom.csv'
results_df.to_csv(results_csv_path, index=False)

# Plot Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Default', 'Default'])
disp.plot(cmap='Blues')
plt.title("Confusion Matrix - Random Forest")
plt.grid(False)
plt.show()

# Plot Accuracy
plt.figure(figsize=(4, 5))
plt.bar(["Accuracy"], [accuracy], color="teal")
plt.ylim(0, 1)
plt.title(f"Model Accuracy: {accuracy:.2f}")
plt.show()

# Classification Report
print("Classification Report:\n", classification_report(y_test, y_pred))

# ROC Curve
y_proba_avg = np.mean([tree.model.predict_proba(X_test)[:, 1] for tree in rf.trees], axis=0)
fpr, tpr, _ = roc_curve(y_test, y_proba_avg)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, label=f"ROC Curve (AUC = {roc_auc:.2f})", color="darkorange")
plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Random Forest")
plt.legend(loc="lower right")
plt.grid(True)
plt.show()

# Feature Importances
feature_names = data.drop(columns=['ID', 'default.payment.next.month']).columns
importances = rf.feature_importances()
indices = np.argsort(importances)[::-1]

plt.figure(figsize=(10, 6))
plt.title("Feature Importances - Random Forest")
plt.bar(range(len(importances)), importances[indices], color="skyblue", align="center")
plt.xticks(range(len(importances)), feature_names[indices], rotation=90)
plt.tight_layout()
plt.show()

# Output result
accuracy, results_csv_path
