import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay, roc_curve, auc

# Load the dataset
file_path = '/content/UCI_Credit_Card_20k.csv'
data = pd.read_csv(file_path)

# Define features and target variable
X = data.drop(columns=['ID', 'default.payment.next.month'])
y = data['default.payment.next.month']

# Normalize numerical features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Custom Logistic Regression Class
class LogisticRegressionCustom:
    def __init__(self):  # Corrected constructor
        self.weights = None
        self.bias = None

    def sigmoid(self, z):
        return 1 / (1 + np.exp(-z))

    def fit(self, X, y, lr=0.01, epochs=1000):
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0

        for _ in range(epochs):
            linear_model = np.dot(X, self.weights) + self.bias
            y_predicted = self.sigmoid(linear_model)

            dw = (1 / n_samples) * np.dot(X.T, (y_predicted - y))
            db = (1 / n_samples) * np.sum(y_predicted - y)

            self.weights -= lr * dw
            self.bias -= lr * db

    def predict(self, X):
        linear_model = np.dot(X, self.weights) + self.bias
        y_predicted = self.sigmoid(linear_model)
        return [1 if i > 0.5 else 0 for i in y_predicted]

    def predict_proba(self, X):  # Added for ROC curve
        linear_model = np.dot(X, self.weights) + self.bias
        return self.sigmoid(linear_model)

# Train and evaluate
log_reg = LogisticRegressionCustom()
log_reg.fit(X_train, y_train, lr=0.01, epochs=1000)
y_pred = log_reg.predict(X_test)
y_proba = log_reg.predict_proba(X_test)
accuracy = accuracy_score(y_test, y_pred)

# Save results
results_df = pd.DataFrame({
    'Actual': y_test.values,
    'Predicted': y_pred
})
results_csv_path = '/content/logistic_regression_results.csv'
results_df.to_csv(results_csv_path, index=False)

# --- Visualization Section ---

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Default', 'Default'])
disp.plot(cmap='Purples')
plt.title('Confusion Matrix - Logistic Regression')
plt.grid(False)
plt.show()

# Accuracy Bar Plot
plt.figure(figsize=(4, 5))
plt.bar(['Accuracy'], [accuracy], color='green')
plt.ylim(0, 1)
plt.title(f'Model Accuracy: {accuracy:.2f}')
plt.ylabel('Accuracy')
plt.show()

# ROC Curve & AUC Score
fpr, tpr, thresholds = roc_curve(y_test, y_proba)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='blue', label=f'ROC Curve (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], linestyle='--', color='grey')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - Logistic Regression')
plt.legend()
plt.grid(True)
plt.show()

# Optional: Print classification report
print("Classification Report:\n", classification_report(y_test, y_pred))

# Output results
accuracy, results_csv_path
