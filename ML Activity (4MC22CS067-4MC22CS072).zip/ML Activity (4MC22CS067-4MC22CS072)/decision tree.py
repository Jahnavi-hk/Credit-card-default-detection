import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from graphviz import Digraph
from IPython.display import Image

# Load the dataset
file_path = '/content/UCI_Credit_Card_20k.csv'
data = pd.read_csv(file_path)

# Define features and target variable
X = data.drop(columns=['ID', 'default.payment.next.month']).values
y = data['default.payment.next.month'].values

# Normalize features
class StandardScalerCustom:
    def fit_transform(self, X):
        self.mean = np.mean(X, axis=0)
        self.std = np.std(X, axis=0)
        return (X - self.mean) / self.std

scaler = StandardScalerCustom()
X = scaler.fit_transform(X)

# Train-test split
class TrainTestSplitCustom:
    def split(self, X, y, test_size=0.2, random_state=None):
        if random_state is not None:
            np.random.seed(random_state)
        indices = np.arange(X.shape[0])
        np.random.shuffle(indices)
        test_size = int(test_size * len(indices))
        train_indices = indices[:-test_size]
        test_indices = indices[-test_size:]
        return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

splitter = TrainTestSplitCustom()
X_train, X_test, y_train, y_test = splitter.split(X, y, test_size=0.2, random_state=42)

# Decision Tree Classifier
class DecisionTreeCustom:
    def __init__(self, max_depth=None):
        self.max_depth = max_depth
        self.tree = None

    def fit(self, X, y):
        self.tree = self._build_tree(X, y, depth=0)

    def predict(self, X):
        return np.array([self._traverse_tree(x, self.tree) for x in X])

    def _gini(self, y):
        classes, counts = np.unique(y, return_counts=True)
        probabilities = counts / len(y)
        return 1 - np.sum(probabilities**2)

    def _split(self, X, y, index, threshold):
        left_indices = X[:, index] <= threshold
        right_indices = X[:, index] > threshold
        return X[left_indices], X[right_indices], y[left_indices], y[right_indices]

    def _best_split(self, X, y):
        best_index, best_threshold = None, None
        best_gini = float("inf")
        for index in range(X.shape[1]):
            thresholds = np.unique(X[:, index])
            for threshold in thresholds:
                _, _, y_left, y_right = self._split(X, y, index, threshold)
                if len(y_left) == 0 or len(y_right) == 0:
                    continue
                gini = (len(y_left) * self._gini(y_left) + len(y_right) * self._gini(y_right)) / len(y)
                if gini < best_gini:
                    best_index, best_threshold, best_gini = index, threshold, gini
        return best_index, best_threshold

    def _build_tree(self, X, y, depth):
        if len(np.unique(y)) == 1 or (self.max_depth is not None and depth >= self.max_depth):
            return np.argmax(np.bincount(y))
        index, threshold = self._best_split(X, y)
        if index is None:
            return np.argmax(np.bincount(y))
        left_X, right_X, left_y, right_y = self._split(X, y, index, threshold)
        return {
            "index": index,
            "threshold": threshold,
            "left": self._build_tree(left_X, left_y, depth + 1),
            "right": self._build_tree(right_X, right_y, depth + 1),
        }

    def _traverse_tree(self, x, tree):
        if not isinstance(tree, dict):
            return tree
        if x[tree["index"]] <= tree["threshold"]:
            return self._traverse_tree(x, tree["left"])
        return self._traverse_tree(x, tree["right"])

    def export_tree_graphviz(self, tree=None, dot=None, node_id=0):
        if tree is None:
            tree = self.tree
            dot = Digraph()
            dot.attr('node', shape='box', style='filled', fillcolor='lightgrey', fontname='helvetica')

        current_id = str(node_id)

        if not isinstance(tree, dict):
            dot.node(current_id, f"Predict: {tree}", fillcolor='lightblue')
            return dot, node_id

        label = f"Feature[{tree['index']}] <= {tree['threshold']:.2f}"
        dot.node(current_id, label)

        left_id = node_id + 1
        dot, new_left_id = self.export_tree_graphviz(tree["left"], dot, left_id)
        dot.edge(current_id, str(left_id), label="True")

        right_id = new_left_id + 1
        dot, new_right_id = self.export_tree_graphviz(tree["right"], dot, right_id)
        dot.edge(current_id, str(right_id), label="False")

        return dot, new_right_id

# Train and evaluate model
decision_tree = DecisionTreeCustom(max_depth=5)
decision_tree.fit(X_train, y_train)
y_pred = decision_tree.predict(X_test)
accuracy = np.mean(y_pred == y_test)

# Save predictions
results_df = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})
results_csv_path = '/content/decision_tree_results_custom.csv'
results_df.to_csv(results_csv_path, index=False)

# Confusion matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["No Default", "Default"])
disp.plot(cmap='Blues')
plt.title('Confusion Matrix - Custom Decision Tree')
plt.grid(False)
plt.show()

# Accuracy plot
plt.figure(figsize=(4, 5))
plt.bar(['Accuracy'], [accuracy], color='green')
plt.ylim(0, 1)
plt.title(f'Model Accuracy: {accuracy:.2f}')
plt.ylabel('Accuracy')
plt.show()

# Generate graphical decision tree
dot, _ = decision_tree.export_tree_graphviz()
tree_image_path = '/content/decision_tree_graph'
dot.render(tree_image_path, format='png', cleanup=True)
Image(tree_image_path + '.png')
